<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrganisasiUsers extends Model
{
    protected $table = 'organisasi_users';
    protected $fillable = [
        'user_id', 'organisasi_id',
    ];
}
