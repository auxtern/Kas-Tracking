<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrganisasiMembers extends Model
{
    protected $table = 'organisasi_members';
    
}
