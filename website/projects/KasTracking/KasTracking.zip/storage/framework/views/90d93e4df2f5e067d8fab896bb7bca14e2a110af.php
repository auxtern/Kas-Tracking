<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Anggota Organisasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('side-menu'); ?>
  <li class="side-item side-item-category mt-4">Menu Organisasi</li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="grid" class="side-menu__icon"></i>
        <span class="side-menu__label">Dasbor</span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/users', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="star" class="side-menu__icon"></i>
        <span class="side-menu__label">Bendahara</span>
        <span class="badge badge-success side-badge"><?php echo $__env->yieldContent('nUsers'); ?></span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item active" href="<?php echo e(route('organisasi/manage/members', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="users" class="side-menu__icon"></i>
        <span class="side-menu__label">Anggota</span>
        <span class="badge badge-success side-badge"><?php echo $__env->yieldContent('nMembers'); ?></span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/money', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="dollar-sign" class="side-menu__icon"></i>
        <span class="side-menu__label">Keuangan</span>
        <span class="badge badge-success side-badge"><?php echo $__env->yieldContent('nMoney'); ?></span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/settings', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="settings" class="side-menu__icon"></i>
        <span class="side-menu__label">Pengaturan</span>
    </a>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <!--Page header-->
    <div class="page-header">
      <div class="page-leftheader">
        <h4 class="page-title mb-0"><?php echo e($organisasi['nama']); ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e(route('organisasi')); ?>"><i class="fa fa-layer-group mr-2 fs-14"></i>Organisasi</a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e(route('organisasi/manage', ["organisasi_id"=>$organisasi['organisasi_id']])); ?>">Dasbor</a>
          </li>
          <li class="breadcrumb-item" aria-current="page">
            <span>Anggota</span>
          </li>
        </ol>
      </div>
    </div>
    <!--End Page header-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
Halaman Anggota
<?php $__env->stopSection(); ?>


<?php $__env->startSection('internalJS'); ?>
  <script src="<?php echo e(asset('js/main/theme1.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>