<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Lupa Kata Sandi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="form-content">
<?php if(session('status')): ?>
    <div class="form-sent show-it">
        <div class="tick-holder">
            <div class="tick-icon"></div>
        </div>
        <h3>Link Reset Berhasil Terkirim</h3>
        <p>Periksa inbox email kamu, untuk melakukan pengaturan ulang kata sandi!</p>

        <a href="<?php echo e(route('login')); ?>">Kembali ke halaman utama</a>
    </div>
<?php else: ?>
    <div class="form-items">
        <a href="<?php echo e(route('login')); ?>" class="d-flex align-items-center text-decoration-none">
            <img  class="mr-3" src="<?php echo e(asset('img/kas-tracking.png')); ?>" style="width: 76px;" alt="">
            <h2 class="text-white"><?php echo e(config('app.name', 'Kas Tracking')); ?></h2>
        </a>
        <h3>Reset Kata Sandi</h3>
        <p class="mb-3">Untuk mengatur ulang kata sandi Anda, masukkan alamat email yang Anda gunakan untuk masuk ke Kas Tracking.</p>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        
            <div class="form-group">
                <span>Alamat Email</span><br>
                <input class="form-control mb-0" type="text" name="email" placeholder="" required>
                <?php if($errors->has('email')): ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-button full-width">
                <button id="submit" type="submit" class="ibtn">Kirim Link Reset</button>
            </div>
        </form>
    </div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>