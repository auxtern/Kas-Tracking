<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('img/kas-tracking.png')); ?>" />

    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <!--Bootstrap css -->
    <link href="<?php echo e(asset('../node_modules/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet"/> 
    
    <!---Icons css-->
    <link href="<?php echo e(asset('../node_modules/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet"/> 

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login/login.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login/login-theme.css')); ?>">

</head>
<body>
<div class="form-body">
    <div class="row">
        <div class="img-holder position-fixed">
            <div class="bg"></div>
            <div class="info-holder">
                <img src="<?php echo e(asset('svg/login/login-graphic.svg')); ?>" alt="">
                <h3 class="text-justify font-weight-light">Jadilah bendahara yang jujur, dengan menerapkan transparansi data informasi terkait pemasukan dan pengeluaran dana di lingkungan organisasi kamu!</h3>
            </div>
        </div>
        <div class="form-holder">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/login/login.js')); ?>"></script>
</body>
</html>