<?php $__env->startSection('title'); ?>
  <?php echo e(config('app.name', 'Kas Tracking')); ?> - Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('internalCSS'); ?>
  <link href="<?php echo e(asset('../node_modules/dropify/dist/css/dropify.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('../node_modules/croppie/croppie.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
  <?php if(Session::get('success')): ?>
  <div class="alert alert-success mt-4 mb-0" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <i class="fa fa-check-circle mr-2" aria-hidden="true"></i> 
      <?php echo e(Session::get('success')); ?>

  </div> 
  <?php elseif(Session::get('error')): ?>
  <div class="alert alert-danger mt-4 mb-0" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <i class="fas fa-exclamation-triangle mr-2" aria-hidden="true"></i>
      <?php echo e(Session::get('error')); ?>

  </div> 
  <?php endif; ?>

  <!--Page header-->
  <div class="page-header">
    <div class="page-leftheader">
      <h4 class="page-title mb-0">Hay, <?php echo e(Auth::user()->nama); ?></h4>
      <ol class="breadcrumb">
        <li class="breadcrumb-item active" aria-current="page">
          <a href="<?php echo e(route('/')); ?>"><i class="fa fa-home mr-2 fs-14"></i>Halaman Utama</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">
          <a href="<?php echo e(route('profile')); ?>">Profil</a>
        </li>
        <li class="breadcrumb-item">
          <span>Pengaturan</span>
        </li>
      </ol>
    </div>
    
  </div>
  <!--End Page header-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">

  <div class="col-xl-3 col-lg-4">
    
    <div class="card box-widget widget-user">
      <form id="form_photo_profile" method="POST" action="<?php echo e(route('profile/change/pictures')); ?>">
        <?php echo csrf_field(); ?>
        <div class="card-header">
          <div class="card-title">Ubah Foto Profile</div>
        </div>
        <div class="widget-user-image mx-auto mt-5">
          <img alt="" class="rounded-circle" src="<?php echo e($url_foto); ?>">
        </div>

          <?php if($errors->has('photo')): ?>
            <div class="alert alert-danger mt-4 mb-0" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?php echo e($errors->first('photo')); ?>

            </div>
          <?php endif; ?>

        <div class="card-body text-center pt-2">
          <input name="photo_profile" id="photo_profile" type="file" class="dropify" data-height="150px">
        </div>

        <input type="hidden" name="photo" id="photo">
      </form>
    </div>

    <div class="card">
      <form method="POST" action="<?php echo e(route('profile/change/password')); ?>">
        <?php echo csrf_field(); ?>

        <div class="card-header">
          <div class="card-title">Ubah Kata Sandi</div>
        </div>

        <div class="card-body">
          <div class="form-group">
            <label class="form-label">Kata Sandi Baru</label>
            <input type="password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password" value="<?php echo e(old('new_password')); ?>">
            <?php if($errors->has('new_password')): ?>
            <span class="text-danger" role="alert">
                <strong><?php echo e($errors->first('new_password')); ?></strong>
            </span>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label class="form-label">Konfirmasi Kata Sandi Baru</label>
            <input type="password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password_confirmation">

          </div>

          <div class="form-group">
            <label class="form-label">Konfirmasi Kata Sandi Lama</label>
            <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>">
            <?php if($errors->has('password')): ?>
            <span class="text-danger" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
            <?php endif; ?>
          </div>

        </div>
        <div class="card-footer text-center">
          <button type="submit" class="btn btn-info">Simpan Perubahan</button>
        </div>

      </form>
    </div>

  </div>

  <div class="col-xl-9 col-lg-8">
    
    <div class="card">
      <div class="card-header">
        <div class="card-title">Ubah Data Diri</div>
      </div>
      <div class="card-body">

        <form method="POST" action="<?php echo e(route('profile/change/personal')); ?>">
          <?php echo csrf_field(); ?>

          <div class="row">

            <div class="col-sm-6 col-md-6">
              <div class="form-group">
                <label class="form-label">Nama Lengkap</label>
              <input name="nama" type="text" class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" placeholder="Nama lengkap" value="<?php echo e(Auth::user()->nama); ?>">
              </div>
            </div>

            <div class="col-sm-6 col-md-6">
              <div class="form-group">
                <label class="form-label">Tanggal Lahir</label>
                <input name="tanggal_lahir" type="date" class="form-control<?php echo e($errors->has('tanggal_lahir') ? ' is-invalid' : ''); ?>" placeholder="Tanggal lahir" value="<?php echo e(Auth::user()->tanggal_lahir); ?>">
              </div>
            </div>
            
            <div class="col-sm-12 col-md-12">
              <div class="form-group">
                <label class="form-label">Bio</label>
                <textarea name="bio" type="date" class="form-control<?php echo e($errors->has('bio') ? ' is-invalid' : ''); ?>" rows="5"><?php echo e(Auth::user()->bio); ?></textarea>
              </div>
            </div>

            <div class="col-sm-12 col-md-12">
              <div class="form-group ">
                <div class="form-label">Jenis Kelamin</div>
                <div class="form-check form-check-inline">
                  <label class="custom-control custom-radio mr-3" style="cursor: pointer;">
                    <input name="jenis_kelamin" type="radio" class="custom-control-input<?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>"  id="jklk" value="Laki-Laki">
                    <span class="custom-control-label">Laki-Laki</span>
                  </label>
                  <label class="custom-control custom-radio" style="cursor: pointer;">
                    <input name="jenis_kelamin" type="radio" class="custom-control-input<?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>" id="jkpr" value="Perempuan">
                    <span class="custom-control-label">Perempuan</span>
                  </label>
                </div>
              </div>
            </div>

            <div class="col-md-12">
              <div class="form-group">
                <label class="form-label">Provinsi Tempat Tinggal</label>
                <select name="provinsi" class="form-control<?php echo e($errors->has('provinsi') ? ' is-invalid' : ''); ?>" name="provinsi" id="provinsi" required>
                  <option value="" disabled selected></option>
                  <?php $__currentLoopData = json_decode(file_get_contents('json/provinsi.json'), true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($prov['nama']); ?>"><?php echo e($prov['nama']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

          </div>

          <div class="card-footer text-right">
            <button type="submit" class="btn  btn-info">Simpan Perubahan</button>
          </div>

        </form>

      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <div class="card-title">Ubah Data Kontak</div>
      </div>

      <div class="card-body">

        <form method="POST" action="<?php echo e(route('profile/change/contact')); ?>">
        <?php echo csrf_field(); ?>
        
          <div class="row">

            <div class="col-sm-6 col-md-6">
              <div class="form-group">
                <label class="form-label">Nomor Whatsapp</label>
                <input type="number" class="form-control<?php echo e($errors->has('whatsapp') ? ' is-invalid' : ''); ?>" placeholder="Nomor whatsapp" name="whatsapp" value="<?php echo e(Auth::user()->whatsapp); ?>">
              </div>
            </div>

            <div class="col-sm-6 col-md-6">
              <div class="form-group">
                <label class="form-label">Alamat Email</label>
                <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Alamat email" name="email" value="<?php echo e(Auth::user()->email); ?>">
              </div>
            </div>

            <div class="col-sm-12 col-md-12">
              <div class="form-group">
                <label class="form-label">Kata Sandi</label>
                <input type="password" class="form-control<?php echo e($errors->has('cpassword') ? ' is-invalid' : ''); ?>" placeholder="Kata sandi" name="cpassword">
              </div>
            </div>

          </div>

          <div class="card-footer text-right">
            <button type="submit" class="btn  btn-info">Simpan Perubahan</button>
          </div>
  
        </form>
      </div>

    </div>
  </div>

  
  <!-- Modal -->
  <div id="upload_modal" class="modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="ubah_photoLabel">Sesuaikan Photo Profil</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row justify-content-md-center">
            <div class="col-md-8 text-center">
              <div id="image_demo" style="width:350px; margin-top:30px"></div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
          <button type="button" class="btn btn-info pangkas_photo">Simpan Perubahan</button>
        </div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('internalJS'); ?>
  <script src="<?php echo e(asset('../node_modules/dropify/dist/js/dropify.min.js')); ?>"></script>
  <script src="<?php echo e(asset('../node_modules/croppie/croppie.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/main/profile-settings.js')); ?>"></script>
  <script src="<?php echo e(asset('js/main/file-upload.js')); ?>"></script>
  <script>
    biodataSetValue('<?php echo e(Auth::user()->jenis_kelamin); ?>', '<?php echo e(Auth::user()->provinsi); ?>');
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>