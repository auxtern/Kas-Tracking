<?php $__env->startSection('content'); ?>
<div class="form-content">
    <div class="form-items">
        <a href="page-login.html" class="d-flex align-items-center text-decoration-none">
            <img  class="mr-3" src="img/kas-tracking.png" style="width: 76px;" alt="">
            <h2 class="text-white"><?php echo e(config('app.name', 'Kas Tracking')); ?></h2>
        </a>
        <div class="page-links">
            <a href="page-login.html" class="active"><?php echo e(__('Masuk')); ?></a>
            <a href="page-register.html"><?php echo e(__('Daftar')); ?></a>
        </div>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="text" name="username" placeholder="Alamat E-mail" required>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>

            <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" type="password" name="password" placeholder="Kata Sandi" required>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>

            <div class="form-button">
                <button id="submit" type="submit" class="ibtn"><?php echo e(__('Masuk')); ?></button> <a href="page-forget.html">Lupa kata sandi?</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>