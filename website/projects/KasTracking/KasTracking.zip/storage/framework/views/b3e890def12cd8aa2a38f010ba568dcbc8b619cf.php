<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Hello
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>