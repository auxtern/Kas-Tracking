<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Dasbor Organisasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('side-menu'); ?>
  <li class="side-item side-item-category mt-4">Menu Organisasi</li>

  <li class="slide">
    <a class="side-menu__item active" href="<?php echo e(route('organisasi/manage', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="grid" class="side-menu__icon"></i>
        <span class="side-menu__label">Dasbor</span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/users', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="star" class="side-menu__icon"></i>
        <span class="side-menu__label">Bendahara</span>
        <span class="badge badge-success side-badge"><?php echo $__env->yieldContent('nUsers'); ?></span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/members', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="users" class="side-menu__icon"></i>
        <span class="side-menu__label">Anggota</span>
        <span class="badge badge-success side-badge"><?php echo $__env->yieldContent('nMembers'); ?></span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/money', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="dollar-sign" class="side-menu__icon"></i>
        <span class="side-menu__label">Keuangan</span>
        <span class="badge badge-success side-badge"><?php echo $__env->yieldContent('nMoney'); ?></span>
    </a>
  </li>

  <li class="slide">
    <a class="side-menu__item bg-white" href="<?php echo e(route('organisasi/manage/settings', ['organisasi_id'=>$organisasi['organisasi_id']])); ?>">
    <i data-feather="settings" class="side-menu__icon"></i>
        <span class="side-menu__label">Pengaturan</span>
    </a>
  </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <!--Page header-->
    <div class="page-header">
      <div class="page-leftheader">
        <h4 class="page-title mb-0"><?php echo e($organisasi['nama']); ?></h4>
        <ol class="breadcrumb">
          <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e(route('organisasi')); ?>"><i class="fa fa-layer-group mr-2 fs-14"></i>Organisasi</a>
          </li>
          <li class="breadcrumb-item" aria-current="page">
            <span>Dasbor</span>
          </li>
        </ol>
      </div>
    </div>
    <!--End Page header-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Row-1 -->
    <div class="row">

      <div class="col-xl-3 col-lg-6 col-md-6 col-xm-6">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Total Pemasukan</h3>
          </div>
          <div class="card-body">
            <h4 class="mb-1 number-font text-success">Rp0,00</h4>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-lg-6 col-md-6 col-xm-6">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Total Pengeluaran</h3>
          </div>
          <div class="card-body">
            <h4 class="mb-1 number-font text-danger">Rp0,00</h4>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-lg-6 col-md-6 col-xm-6">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Sisa Dana Tersimpan</h3>
          </div>
          <div class="card-body">
            <h4 class="mb-1 number-font text-info">Rp0,00</h4>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-lg-6 col-md-6 col-xm-6">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Total Anggota</h3>
          </div>
          <div class="card-body">
            <h4 class="mb-1 number-font text-info">0</h4>
          </div>
        </div>
      </div>

    </div>
    <!-- End Row-1 -->

    <!-- Row-2 -->
    <div class="row">
      <div class="col-xl-8 col-lg-8 col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Analisa Keuangan Bulanan</h3>
          </div>
          <div class="card-body">

            <h5 class="text-muted"><em>Laporan Bulan ini</em></h5>
            <div class="row mb-4">
              <div class="col-xl-3 col-6">
                <p class="mb-1">Pemasukan</p>
                <h3 class="mb-0 fs-20 number-font1 text-success">Rp0,00</h3>
              </div>

              <div class="col-xl-3 col-6">
                <p class="mb-1">Pengeluaran</p>
                <h3 class="mb-0 fs-20 number-font1 text-danger">Rp0,00</h3>
              </div>
            </div>

            <div id="echart1" class="chart-tasks chart-dropshadow text-center"></div>
            
            <div class="text-center mt-2">
              <span class="mr-4"><span class="dot-label bg-success"></span>Pemasukan</span>
              <span><span class="dot-label bg-danger"></span>Pengeluaran</span>
            </div>

          </div>

        </div>
      </div>

      <div class="col-xl-4 col-lg-4 col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Aktivitas Terbaru</h3>
          </div>

          <div class="card-body">
            <div class="latest-timeline scrollbar3" id="scrollbar3">
              <ul class="timeline mb-0">
                <li class="mt-0">
                  <div class="d-flex">
                    <span class="time-data">Task Finished</span
                    ><span class="ml-auto text-muted fs-11"
                      >09 June 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Joseph Ellison</span>
                    finished task on<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      Project Management</a
                    >
                  </p>
                </li>
                <li>
                  <div class="d-flex">
                    <span class="time-data">New Comment</span
                    ><span class="ml-auto text-muted fs-11"
                      >05 June 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Elizabeth Scott</span>
                    Product delivered<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      Service Management</a
                    >
                  </p>
                </li>
                <li>
                  <div class="d-flex">
                    <span class="time-data">Target Completed</span
                    ><span class="ml-auto text-muted fs-11"
                      >01 June 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Sonia Peters</span> finished
                    target on<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      this month Sales</a
                    >
                  </p>
                </li>
                <li>
                  <div class="d-flex">
                    <span class="time-data">Revenue Sources</span
                    ><span class="ml-auto text-muted fs-11"
                      >26 May 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Justin Nash</span> source
                    report on<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      Generated</a
                    >
                  </p>
                </li>
                <li>
                  <div class="d-flex">
                    <span class="time-data">Dispatched Order</span
                    ><span class="ml-auto text-muted fs-11"
                      >22 May 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Ella Lambert</span> ontime
                    order delivery
                    <a
                      href="#"
                      class="font-weight-semibold"
                      >Service Management</a
                    >
                  </p>
                </li>
                <li>
                  <div class="d-flex">
                    <span class="time-data">New User Added</span
                    ><span class="ml-auto text-muted fs-11"
                      >19 May 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Nicola Blake</span> visit
                    the site<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      Membership allocated</a
                    >
                  </p>
                </li>
                <li>
                  <div class="d-flex">
                    <span class="time-data">Revenue Sources</span
                    ><span class="ml-auto text-muted fs-11"
                      >15 May 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Richard Mills</span> source
                    report on<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      Generated</a
                    >
                  </p>
                </li>
                <li class="mb-0">
                  <div class="d-flex">
                    <span class="time-data">New Order Placed</span
                    ><span class="ml-auto text-muted fs-11"
                      >11 May 2020</span
                    >
                  </div>
                  <p class="text-muted fs-12">
                    <span class="text-info">Steven Hart</span> is proces
                    the order<a
                      href="#"
                      class="font-weight-semibold"
                    >
                      #987</a
                    >
                  </p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

    </div>
    <!-- End Row-2 -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('internalJS'); ?>
  <script src="<?php echo e(asset('js/main/theme1.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>