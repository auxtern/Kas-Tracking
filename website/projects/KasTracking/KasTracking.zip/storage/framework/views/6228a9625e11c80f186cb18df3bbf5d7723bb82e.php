<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('nOrganisasi'); ?>
    <?php echo e(sizeof($organisasi)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <!--Page header-->
    <div class="page-header">
      <div class="page-leftheader">
        <h4 class="page-title mb-0">Organisasi yang diikuti</h4>
        </ol>
      </div>
      <div class="page-rightheader">
        <div class="btn btn-list">
          <a href="<?php echo e(route('organisasi/create')); ?>" class="btn btn-info">
            <i class="fa fa-plus-circle mr-1"></i> Buat Organisasi
          </a>
        </div>
      </div>
    </div>
    <!--End Page header-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap">
  <?php $__currentLoopData = $organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-6 col-lg-6">
    <div class="card overflow-hidden">
      <div class="card-status bg-primary"></div>
      <div class="card-header">
        <h3 class="card-title text-dark">
          <?php echo e($item['nama']); ?>

        </h3>
        <div class="card-options">
          <a href="#" class="card-options-collapse mr-2" data-toggle="card-collapse">
            <i class="fa fa-chevron-up"></i>
          </a>
          <a href="#" class="card-options-remove mr-2" data-toggle="card-remove">
            <i class="fa fa-times">
              </i></a>
        </div>
      </div>
      <div class="card-body text-center">
        <?php
            $obj = DB::select('select foto, jenis_kelamin from users where id in (select user_id from organisasi_users where organisasi_id = ?)', [$item['organisasi_id']]);
            $banyakUser = sizeof($obj);
        ?>

        <div class="avatar-list">
          <?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $user = (array) $row;
                $foto = App\Helpers\Tools::ambilFotoProfil($user['foto'], $user['jenis_kelamin']); 
            ?>
            <span class="avatar avatar-xxl bradius" style="background-image: url(<?php echo e($foto); ?>)"></span>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-3">
          <?php if($banyakUser > 1): ?>
            <p class="text-muted">Kamu dan <?php echo e(($banyakUser - 1)); ?> orang lainnya menjadi bendahara dalam organisasi ini.</p> 
          <?php else: ?>
            <p class="text-muted">Hanya kamu yang menjadi bendahara dalam organisasi ini.</p>
          <?php endif; ?>
        </div>
        
        <div class="mt-5">
          <a href="<?php echo e(route('organisasi/manage', ["organisasi_id" => $item['organisasi_id']])); ?>" class="btn btn-sm btn-info text-decoration-none">Kelolah</a>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('internalJS'); ?>
  
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>