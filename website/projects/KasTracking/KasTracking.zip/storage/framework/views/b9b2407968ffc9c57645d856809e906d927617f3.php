<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Tambah Organisasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <!--Page header-->
    <div class="page-header">
        <div class="page-leftheader">
          <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">
              <a href="<?php echo e(route('/')); ?>"><i class="fa fa-layer-group mr-2 fs-14"></i> Organisasi</a>
            </li>
            <li class="breadcrumb-item" aria-current="page">
              <span>Buat</span>
            </li>
          </ol>
        </div>
    </div>
      <!--End Page header-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
  <div class="card">
    <div class="card-header">
      <h4 class="card-title">Buat Organisasi</h4>
    </div>
    <div class="card-body">
      
      <form class="form-horizontal">
        
        <div class="form-group row">
          <label for="nama" class="col-md-3 form-label">Nama</label>
          <div class="col-md-9">
            <input name="nama" type="text" class="form-control" id="nama" placeholder="Nama organisasi...">
          </div>
        </div>

        <div class="form-group row">
          <label for="lokasi" class="col-md-3 form-label">Lokasi</label>
          <div class="col-md-9">
            <input name="lokasi" type="lokasi" class="form-control" id="lokasi" placeholder="Lokasi organisasi...">
          </div>
        </div>

        <div class="text-right">
            <button type="submit" class="btn btn-info">Simpan Data</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('internalJS'); ?>
  
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>