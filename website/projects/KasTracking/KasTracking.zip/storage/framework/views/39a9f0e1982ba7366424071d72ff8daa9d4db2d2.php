<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Reset Kata Sandi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="form-content">
    <div class="form-items">
        <a href="<?php echo e(route('login')); ?>" class="d-flex align-items-center text-decoration-none">
            <img  class="mr-3" src="<?php echo e(asset('img/kas-tracking.png')); ?>" style="width: 76px;" alt="">
            <h2 class="text-white"><?php echo e(config('app.name', 'Kas Tracking')); ?></h2>
        </a>
        <h3>Buat Kata Sandi Baru</h3>

        <form method="POST" action="<?php echo e(route('password.update')); ?>">
        <?php echo csrf_field(); ?>

            <input type="hidden" name="token" value="<?php echo e($token); ?>">
        
            <div class="form-group">
                <span>Alamat Email</span><br>
                <input class="form-control mb-0" type="text" name="email" placeholder="" value="<?php echo e($email ?? old('email')); ?>" required autofocus>
                <?php if($errors->has('email')): ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <span>Kata Sandi Baru</span><br>
                <input class="form-control mb-0" type="password" name="password" placeholder="" required>
                <?php if($errors->has('password')): ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>


            <div class="form-group">
                <span>Ulangi Kata Sandi</span><br>
                <input class="form-control mb-0" type="password" name="password_confirmation" placeholder="" required>
            </div>


            <div class="form-button full-width">
                <button id="submit" type="submit" class="ibtn">Reset Kata Sandi</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>