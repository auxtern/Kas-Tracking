<?php $__env->startSection('title'); ?>
<?php echo e(config('app.name', 'Kas Tracking')); ?> - Masuk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="form-content">
    <div class="form-items">
        <a href="<?php echo e(route('login')); ?>" class="d-flex align-items-center text-decoration-none">
            <img  class="mr-3" src="<?php echo e(asset('img/kas-tracking.png')); ?>" style="width: 76px;" alt="">
            <h2 class="text-white"><?php echo e(config('app.name', 'Kas Tracking')); ?></h2>
        </a>
        <div class="page-links">
            <a href="<?php echo e(route('login')); ?>" class="active"><?php echo e(__('Masuk')); ?></a>
            <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Daftar')); ?></a>
        </div>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <span>Email</span><br>
                <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> mb-0" type="text" name="email" placeholder="" value="<?php echo e(old('email')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <span>Kata Sandi</span><br>
                <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> mb-0" type="password" name="password" placeholder="" value="<?php echo e(old('password')); ?>" required>
                <?php if($errors->has('password')): ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            
            <?php if(Route::has('password.request')): ?>
                <div class="form-button">
                    <button id="submit" type="submit" class="ibtn"><?php echo e(__('Masuk')); ?></button> <a href="<?php echo e(route('password.request')); ?>">Lupa kata sandi?</a>
                </div>
            <?php endif; ?>
            
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>